# @sportschord/print-pipeline

The shared headless **print → Google Drive** rendering engine for SportsChord poster studios.

It was extracted from `f1app`'s `lib/print-generator.server.js` and `Tennis`'s
`src/lib/print/*` — which were copy-paste ports of each other that had begun to drift
(the same Drive-nesting fix was hand-applied to both repos separately). This package is
the single source of truth so a fix lands once.

## What's shared vs. what each app injects

The engine is identical across studios. Only **three things** differ per app, and each is
injected at the call site:

| Seam | Injected as | Example |
|---|---|---|
| Which page to capture + its geometry | `RenderSpec.pagePath` + `RenderSpec.geometry` | `/print?viz=poster…`, A1 @ 300 DPI |
| When the artwork is "ready" | `RenderSpec.expectedDataset` | `{ viz, tournament, division }` |
| Where the file lands in Drive | `DriveTarget` | `["Tennis","Tennis Majors","<design>"]` / `A.pdf` |

Everything else — Drive auth/config, folder-ensure, upload-or-overwrite, browser launch,
the data-ready render loop, the >8192px slice-and-stitch codec, and the shared-secret
gate — lives here.

## Public API

```ts
import {
  renderSnapshot,    // (request, spec) -> RenderedPrint  (own browser lifecycle)
  renderOnPage,      // (page, baseUrl, spec) -> RenderedPrint  (batch: reuse one page)
  uploadToDrive,     // (rendered, target) -> DriveUploadResult
  getGoogleDriveConfig,
  createPrintAuth,   // (cookieName) -> { isAuthorizedPrintRequest, PRINT_AUTH_COOKIE, … }
  stitchPngsVertically,
  type RenderSpec, type RenderedPrint, type DriveTarget,
} from "@sportschord/print-pipeline";
```

## Why this is also a fix, not just DRY

Tennis's version had three correctness improvements that f1app never received. Adopting
the shared engine back-ports them to f1app:

1. **`png-stitch`** — f1app has none, so its 300-DPI A-series PNGs (>8192 device px) WRAP
   in production Chromium (top of the artwork repeats over the footer). The engine slices
   and stitches above the cap.
2. **`domcontentloaded` + interval-polled ready handshake** — replaces f1app's flaky
   `networkidle2` (which never settles under dev HMR) and rAF polling (throttled when the
   headless page is occluded).
3. **`headless: "shell"`** — the classic headless build; the "new" mode stalls
   `captureScreenshot` on large high-DPI surfaces.

## Peer dependencies

The heavy/native bits are **peer dependencies** — each consuming app already has them, and
we must not bundle a second copy of Chromium:

- `@sparticuz/chromium`, `puppeteer-core`, `googleapis` (required)
- `puppeteer` (optional — local dev only)

## Build

```bash
npm install        # dev: typescript + types + googleapis/puppeteer-core for type-check
npm run typecheck  # tsc --noEmit
npm run build      # emit dist/ (CJS + .d.ts)
npm run test       # vitest (png codec round-trip)
```

## Env vars (read by `getGoogleDriveConfig`)

`GOOGLE_DRIVE_FOLDER_ID` (Import Drive root), then **either** OAuth
(`GOOGLE_OAUTH_CLIENT_ID` / `_SECRET` / `_REFRESH_TOKEN`) **or** a service account
(`GOOGLE_SERVICE_ACCOUNT_JSON`, raw or base64). The gate uses `PRINT_EXPORT_TOKEN`.

See `MIGRATION.md` for how `f1app` and `Tennis` each become a ~30-line adapter.
